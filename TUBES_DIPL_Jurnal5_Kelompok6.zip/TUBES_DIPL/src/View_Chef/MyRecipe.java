package View_Chef;

public class MyRecipe {

    public static void main(String[] args) {
        BerandaChef frmBerandaChef = new BerandaChef();
        frmBerandaChef.setLocationRelativeTo(null);
        frmBerandaChef.setVisible(true);
        frmBerandaChef.setTitle("Beranda Chef");
        
        UploadVideo frmUploadVideo = new UploadVideo();
        frmUploadVideo.setLocationRelativeTo(null);
        frmUploadVideo.setVisible(true);
        frmUploadVideo.setTitle("Upload Video");
    }
    
}
